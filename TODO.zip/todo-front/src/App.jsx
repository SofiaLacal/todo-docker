import './App.css'

function App() {

  return (
    <>
      <div>
      </div>
      <h1>Bienvenido a la lista de tareas</h1>
      <h2>Autores: Pablo Herrero, Javier Monzón, Sofía Lacal</h2>
      <div className="contenedor-principal">
        <p>
          Entra al enlace para acceder a las diferentes listas
        </p>
        <div className='contenedor-enlaces'>
          <p className='enlace'>Enlace 1</p>
          <p className='enlace'>Enlace 2</p>
          <p className='enlace'>Enlace 3</p>
        </div>
      </div>
    </>
  )
}

export default App
